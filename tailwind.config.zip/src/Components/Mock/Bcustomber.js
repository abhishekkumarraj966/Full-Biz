
const Bcustomber = [
  {
    name: "Hailey Food",
    description: "Best food nectar you ",
    location: "Gandhinagar Gujarat",
    image: "",
    description2: "wish to get",
  },
  {
    name: "Hailey Food",
    description: "Best food nectar you ",
    location: "Gandhinagar Gujarat",
    image: "",
    description2: "wish to get",
  },
  {
    name: "Hailey Food",
    description: "Best food nectar you ",
    location: "Gandhinagar Gujarat",
    image: "",
    description2: "wish to get",
  },
  {
    name: "Hailey Food",
    description: "Best food nectar you ",
    location: "Gandhinagar Gujarat",
    image: "",
    description2: "wish to get",
  },
  {
    name: "Hailey Food",
    description: "Best food nectar you Best food nectar you  ",
    location: "Gandhinagar Gujarat",
    image: "",
    description2: "wish to get",
  },
];
export default Bcustomber;
