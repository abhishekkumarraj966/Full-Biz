import img2 from "../assites/B2.png"
import img1 from "../assites/B1.png"
const Slider =[
    {
        img:img1,
        alt:"Lodinge..."
    },
    {
        img:img2,
        alt:"Lodinge..."
    }

];
export default Slider