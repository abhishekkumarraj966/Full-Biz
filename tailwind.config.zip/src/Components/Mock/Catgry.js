const Catgry = [
  {
    text: "Baker",
  },
  {
    text: "Readymade Cloth",
  },
  {
    text: "Property Delaer ",
  },
  {
    text: "IT Service",
  },
  {
    text: "Baker",
  },
  {
    text: "Readymade Cloth",
  },
  {
    text: "Property Delaer ",
  },
  {
    text: "IT Service",
  },
 
];
export default Catgry;
