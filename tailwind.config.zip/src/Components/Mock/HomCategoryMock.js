import img from "../assites/storefront.png"
const HomCategoryMock = [
  { id: 1, name: "Restaurants", imgSrc: img },
  { id: 2, name: "Hotels", imgSrc: img },
  { id: 3, name: "Beauty Spa", imgSrc: img },
  { id: 4, name: "Home Decor", imgSrc: img },
  { id: 5, name: "Wedding Planning", imgSrc: img },
  { id: 6, name: "Education", imgSrc: img },
  { id: 7, name: "Rent & Hire", imgSrc: img },
  
];
export default HomCategoryMock;