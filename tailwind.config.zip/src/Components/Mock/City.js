const City = [
    "Home Decor",
    "Cosmetics",
    "Electronics",
    "Apparel",
    "Fitness Gear",
    "Vitamins",
    "Books",
    "Toys",
    "Car Accessories",
    "Pet Toys",
  ];
  export default City;
  