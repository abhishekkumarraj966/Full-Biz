import img from "../assites/storefront.png"
const CategoryMock = [
  { id: 1, name: "Restaurants", imgSrc: img },
  { id: 2, name: "Hotels", imgSrc: img },
  { id: 3, name: "Beauty Spa", imgSrc: img },
  { id: 4, name: "Home Decor", imgSrc: img },
  { id: 5, name: "Wedding Planning", imgSrc: img },
  { id: 6, name: "Education", imgSrc: img },
  { id: 7, name: "Rent & Hire", imgSrc: img },
  { id: 8, name: "Hospitals", imgSrc: img },
  { id: 9, name: "PG/Hostels", imgSrc: img },
  { id: 10, name: "Estate Agent", imgSrc: img },
  { id: 11, name: "Dentists", imgSrc: img },
  { id: 12, name: "Gym", imgSrc: img },
  { id: 13, name: "Consultants", imgSrc: img },
  { id: 14, name: "Event Organisers", imgSrc: img },
  { id: 15, name: "Driving Schools", imgSrc: img },
  { id: 16, name: "Packers & Movers", imgSrc: img },
  { id: 17, name: "Courier Service", imgSrc: img },
  { id: 18, name: "Contractors", imgSrc: img },
  { id: 19, name: "Pet Shops", imgSrc: img },
  { id: 20, name: "Coaching", imgSrc: img },
];
export default CategoryMock;