import React from 'react'

const Cookieguidelines = () => {
  return (
    <div>Cookieguidelines</div>
  )
}

export default Cookieguidelines