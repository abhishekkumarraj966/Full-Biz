import React from 'react'

const Termsconditions = () => {
  return (
    <div>Termsconditions</div>
  )
}

export default Termsconditions