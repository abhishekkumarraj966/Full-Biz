import React from 'react'

function Careers() {
  return (
    <div>Careers</div>
  )
}

export default Careers