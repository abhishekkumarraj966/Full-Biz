import React from 'react'

const Faq = () => {
  return (
    <div>Faq</div>
  )
}

export default Faq