import React from 'react'

const Affilatepg = () => {
  return (
    <div>Affilatepg</div>
  )
}

export default Affilatepg