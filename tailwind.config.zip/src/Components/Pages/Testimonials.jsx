import React from 'react'

const Testimonials = () => {
  return (
    <div>Testimonials</div>
  )
}

export default Testimonials