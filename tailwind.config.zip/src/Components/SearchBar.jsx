// SearchBar.jsx
import React, { useEffect, useState } from 'react';
import Select from 'react-select';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import http from "../http";

const SearchBar = () => {
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch cities from the API
    http.get('/cities')
      .then(response => {
        const cityOptions = response.data.map(city => ({
          value: city.id,
          label: city.name,
        }));
        setCities(cityOptions);
      })
      .catch(error => {
        console.error('There was an error fetching the cities!', error);
      });
  }, []);

  const handleSearch = () => {
    // Submit the search request
    const cityId = selectedCity ? selectedCity.value : '';
    http.get(`/search/${cityId}`, { params: { search: searchQuery } })
      .then(response => {
        // Navigate to the SearchPage with search results
        navigate('/search', { state: { results: response.data } });
      })
      .catch(error => {
        console.error('There was an error with the search!', error);
      });
  };

  return (
    <>
    
<h1 class="mb-4 mt-20 text-4xl font-extrabold text-center leading-none tracking-tight text-gray-600 md:text-5xl lg:text-6xl">Search for <span class="text-red-600">Business</span></h1>

    <div className=" flex w-fit mx-auto mt-10 mb-20 bg-gray-500 rounded-lg">
      <div className="">
        <Select
          options={cities}
          value={selectedCity}
          onChange={setSelectedCity}
          placeholder="Select a city"
          className="w-60 cursor-auto"
          styles={{
            control: (base) => ({
              ...base,
              backgroundColor: 'gray-600',
              border: 'none',
              boxShadow: 'none',
            }),
            placeholder: (base) => ({
              ...base,
              color: 'red-600',
            }),
          }}
        />
      </div>
      <div>
        <input
          type="text"
          className="w-80 px-4 py-2 bg-transparent text-red-600 placeholder-red-600 outline-none"
          placeholder="Search query"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>
      <button
        onClick={handleSearch}
        className="w-40 bg-red-600 text-white px-4 py-2 hover:bg-red-700 rounded-r-lg transition-colors"
      >
        Search
      </button>
    </div>
    </>
  );
};

export default SearchBar;
