

import Fredany from './Fredany-main';
// import Template1 from './Template1/index';
// import Fashionista from './Fashionista-main/index';
// import Beauty from './Beuty-main/index';
// import Web4 from './Web4-main/index';
// import furnitureshop from './furnitureshop-main/index';
// import web5 from './web5-main/index';
// import web6 from './web6-main/index';

const templateMap = {
    // 'template1': Template1,
    'template2': Fredany,
    // 'template3': Fashionista,
    // 'template4': Beauty,
    // 'template5': Web4,
    // 'template6': furnitureshop,
    // 'template7': web5,
    // 'template8': web6,
    // Add other template mappings here
};

export default templateMap;
