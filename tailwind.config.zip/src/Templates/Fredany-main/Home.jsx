import React from 'react'


const Home = () => {
  return (
    <div className='h-[231px]  sm:h-[450px] lg:h-[800px]  bgimage' id='home'>
        
    </div>
  )
}

export default Home