const product = [
  {
    img: "/assets/ptest.jpg",
    textp: "Comfy Sofa",
    teatA: `“ It is a long established fact that a reader will be
        tracked distracted by the readable content of a page is when
        looking at its layout. The point of using Lorem of
        distribution it look like readable English “ `,
  },
  {
    img:"/assets/ptest.jpg",
    textp: "Comfy Sofa",
    teatA: `“ It is a long established fact that a reader will be
        tracked distracted by the readable content of a page is when
        looking at its layout. The point of using Lorem of
        distribution it look like readable English “ `,
  },
  {
    img:"/assets/ptest.jpg",
    textp: "Comfy Sofa",
    teatA: `“ It is a long established fact that a reader will be
        tracked distracted by the readable content of a page is when
        looking at its layout. The point of using Lorem of
        distribution it look like readable English “ `,
  },
  {
    img: "/assets/ptest.jpg",
    textp: "Comfy Sofa",
    teatA: `“ It is a long established fact that a reader will be
        tracked distracted by the readable content of a page is when
        looking at its layout. The point of using Lorem of
        distribution it look like readable English “ `,
  },
];
export default product;
