import img1 from"../assites/img1.png";
import img2 from "../assites/img2.png";
import img3 from "../assites/img3.png";
const BlogeMock = [
  {
    imgSrc: img1,
    title: "Hello",
  },
  {
    imgSrc: img2,
    title: "Hello2",
  },
  {
    imgSrc: img3,
    title: "hello3",
  },
];
export default BlogeMock;
